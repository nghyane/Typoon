"""Lens detector package — two-phase OCR (tile + bubble).

Import directly:
    from typoon.vision.detectors.lens.detector import LensBlocksDetector
"""
