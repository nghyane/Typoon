"""Prepare raw source images into a Chapter of prepared JPEG pages.

Strategy auto-detection:
  - Sample pages at 25%, 50%, 75% of chapter.
  - Measure color ratio: fraction of pixels with HSV saturation > SAT_THRESHOLD.
  - If color ratio >= COLOR_RATIO_THRESHOLD → webtoon/manhwa → stitch strategy.
  - Otherwise → one_to_one (standard manga page-per-file).

Stitch strategy:
  - vstack all raw slices into one long strip.
  - Re-cut using vectorized pixel-comparison (stitchtoon algorithm):
      valid row = max neighbor diff <= threshold AND row spread <= threshold
      confirmed row = window consecutive valid rows (avoids single-row false positives)
      nearest confirmed row to each target cut point wins; hard cut fallback if none.
  - Guarantees no bubble is split at a prepared page boundary.

Output is a directory of `<i:04d>.jpg` files (JPEG q=92), ready for
`bunle.pack_dir` passthrough. Prepared pixels are the canonical coordinate
source for all downstream stages — the contract is **consistency**
(every stage decodes the same bytes for page i), not bit-level
fidelity. JPEG q=92 measures higher PSNR than the WebP q=92 it
replaced (39.6 vs 38.4 dB on a real 7 Mpx page) at ~12× faster encode
(29 ms vs 350 ms) and ~4 % smaller files. bunle stores JPEG
byte-identical (format id 1 in the .bnl spec).
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal, Protocol

import cv2
import numpy as np

from typoon.domain.prepared import Chapter, Page
from typoon.runs.artifacts import ArtifactSink

_COLOR_RATIO_THRESHOLD = 0.15
_SAT_THRESHOLD         = 30       # HSV saturation, out of 255

# Aspect-ratio confirmation for the colour signal. A page is "tall"
# when its H/W ≥ this — typical of vertical-scroll formats (webtoon
# strips are 3-6×) and atypical of printed manga (1.3-1.5×) or spreads
# (< 1×). Used ONLY to confirm the colour vote — colour-and-tall
# stitches, colour-but-not-tall keeps one_to_one.
_TALL_ASPECT_RATIO = 2.0

_MAX_PAGE_HEIGHT = 4096           # target prepared page height for stitch
_MIN_PAGE_HEIGHT = 2048           # minimum — prevents cluster of cuts in whitespace
_SENSITIVITY     = 97             # 0-100; higher = stricter valid-row check
_WINDOW          = 10             # consecutive valid rows required to confirm
_X_MARGINS       = 10             # pixels to ignore on each side during detection


class RawChapterSource(Protocol):
    def page_count(self) -> int: ...
    def load_page(self, index: int) -> np.ndarray: ...


def prepare_chapter(
    source: RawChapterSource,
    out_dir: Path,
    *,
    strategy: Literal["auto", "one_to_one", "stitch"] = "auto",
    source_label: str = "",
    artifacts: ArtifactSink | None = None,
) -> Chapter:
    """Write `<i:04d>.jpg` (JPEG q=92) into `out_dir`. Returns PreparedChapter."""
    out_dir.mkdir(parents=True, exist_ok=True)

    color_ratio = _chapter_color_ratio(source)
    is_color    = color_ratio >= _COLOR_RATIO_THRESHOLD

    if strategy == "auto":
        # Two signals must agree before we commit to stitch:
        #
        #   colour (primary) — webtoon / manhwa are almost always
        #     coloured; printed manga is overwhelmingly greyscale.
        #     Greyscale pages alone never stitch.
        #
        #   aspect (confirming) — vertical-scroll pages are tall
        #     (H/W ≥ 2). Colour-but-not-tall sources are usually
        #     colour-edition manga, doujin, or covers — those must
        #     stay one_to_one. Without this guard, a single colour
        #     misread on a chapter that is actually a printed manga
        #     would corrupt every downstream stage.
        #
        # Aspect alone is not enough either: some scanlation groups
        # output webtoons as single tall PNGs (would pass) AND
        # cropped landscape banners (would fail). Coupling the two
        # gives a high-precision, low-recall trigger — fine, because
        # false negatives just lose the stitch optimisation while
        # false positives break the chapter.
        is_tall  = _chapter_is_tall(source)
        strategy = "stitch" if (is_color and is_tall) else "one_to_one"

    if strategy == "stitch":
        pages, groups = _prepare_stitch(source, out_dir, artifacts)
    else:
        pages, groups = _prepare_one_to_one(source, out_dir, artifacts)

    chapter = Chapter(source=source_label, pages=tuple(pages),
                      is_color=is_color, strategy=strategy)

    if artifacts is not None:
        artifacts.write_json("01_prepare", "groups.json", {
            "version":     1,
            "strategy":    strategy,
            "is_color":    is_color,
            "color_ratio": round(color_ratio, 4),
            "groups":      groups,
        })

    return chapter


def _chapter_color_ratio(source: RawChapterSource) -> float:
    """Mean color ratio over three sample pages. 0.0 for empty chapters."""
    n = source.page_count()
    if n == 0:
        return 0.0
    indices = sorted({n // 4, n // 2, 3 * n // 4})
    ratios  = [_color_ratio(source.load_page(i)) for i in indices]
    return sum(ratios) / len(ratios)


def _chapter_is_tall(source: RawChapterSource) -> bool:
    """True only when EVERY sampled middle+late page is tall (H/W ≥
    `_TALL_ASPECT_RATIO`).

    Picks a few pages from the middle and end of the chapter — the first
    few entries in a ZIP are usually cover / credits / table-of-contents
    which can have any aspect, so we ignore them. A page is "tall" when
    it looks like a webtoon strip (3-6× tall) rather than a printed
    manga page (1.3-1.5×) or a spread (≤ 1×).

    Defaults SAFE: if the chapter is empty or any sampled page is not
    clearly tall, we return False so the caller falls back to
    `one_to_one`. Stitch is only correct on confirmed vertical-scroll
    formats; getting it wrong on a printed manga corrupts every
    downstream stage. False negatives (treating a real webtoon as
    one_to_one) just disable the stitch optimisation, which is
    recoverable; false positives (stitching a manga) are not.
    """
    n = source.page_count()
    if n == 0:
        return False
    # Middle and end-of-chapter samples; dedup and clamp to valid indices.
    candidates = {n // 2, (2 * n) // 3, (3 * n) // 4, max(0, n - 2)}
    indices    = sorted(i for i in candidates if 0 <= i < n)
    if not indices:
        return False
    for i in indices:
        img  = source.load_page(i)
        h, w = img.shape[:2]
        if w <= 0 or h / w < _TALL_ASPECT_RATIO:
            return False
    return True


def _color_ratio(image: np.ndarray) -> float:
    small = cv2.resize(image, (256, 256)) if min(image.shape[:2]) > 256 else image
    hsv   = cv2.cvtColor(small, cv2.COLOR_RGB2HSV)
    return float(np.count_nonzero(hsv[:, :, 1] > _SAT_THRESHOLD)) / (hsv.shape[0] * hsv.shape[1])


def _prepare_one_to_one(
    source: RawChapterSource,
    out_dir: Path,
    artifacts: ArtifactSink | None,
) -> tuple[list[Page], list[list[int]]]:
    pages:  list[Page]      = []
    groups: list[list[int]] = []
    for i in range(source.page_count()):
        img  = source.load_page(i)
        h, w = img.shape[:2]
        _write_prepared(out_dir / f"{i:04d}.jpg", img)
        pages.append(Page(index=i, width=w, height=h))
        groups.append([i])
        if artifacts is not None:
            artifacts.write_image("01_prepare", f"prepared_{i:04d}.png", img)
    return pages, groups


def _prepare_stitch(
    source: RawChapterSource,
    out_dir: Path,
    artifacts: ArtifactSink | None,
) -> tuple[list[Page], list[list[int]]]:
    raw = [source.load_page(i) for i in range(source.page_count())]
    w   = _modal_width(raw)
    raw = [_resize_to_width(img, w) for img in raw]

    strip     = np.concatenate(raw, axis=0)
    total_h   = strip.shape[0]
    confirmed = _confirmed_rows(strip)
    boundaries = _raw_boundaries(raw)

    pages:  list[Page]      = []
    groups: list[list[int]] = []
    prev    = 0
    out_idx = 0
    target  = _MAX_PAGE_HEIGHT

    while target < total_h:
        lo  = prev + _MIN_PAGE_HEIGHT
        hi  = min(prev + int(_MAX_PAGE_HEIGHT * 1.5), total_h)
        cut = _nearest_confirmed(confirmed, lo, hi, prev + _MAX_PAGE_HEIGHT)
        if cut is None:
            cut = _nearest_confirmed(confirmed, lo, total_h, prev + _MAX_PAGE_HEIGHT)
        if cut is None:
            cut = prev + _MAX_PAGE_HEIGHT  # hard fallback: no valid row anywhere

        _write_segment(strip, prev, cut, out_dir, out_idx, pages, groups, boundaries, artifacts)
        out_idx += 1
        prev    = cut
        target  = prev + _MAX_PAGE_HEIGHT

    if prev < total_h:
        _write_segment(strip, prev, total_h, out_dir, out_idx, pages, groups, boundaries, artifacts)

    return pages, groups


def _write_segment(
    strip: np.ndarray,
    start: int, end: int,
    out_dir: Path,
    out_idx: int,
    pages: list[Page],
    groups: list[list[int]],
    boundaries: list[tuple[int, int]],
    artifacts: ArtifactSink | None,
) -> None:
    seg  = strip[start:end]
    h, w = seg.shape[:2]
    _write_prepared(out_dir / f"{out_idx:04d}.jpg", seg)
    pages.append(Page(index=out_idx, width=w, height=h))
    groups.append([i for i, (rs, re) in enumerate(boundaries) if rs < end and re > start])
    if artifacts is not None:
        artifacts.write_image("01_prepare", f"prepared_{out_idx:04d}.png", seg)


def _confirmed_rows(strip: np.ndarray) -> np.ndarray:
    """Bool array (H,): True where a window of consecutive valid rows starts."""
    gray = cv2.cvtColor(strip, cv2.COLOR_RGB2GRAY)
    arr  = gray[:, _X_MARGINS: gray.shape[1] - _X_MARGINS] if _X_MARGINS > 0 else gray

    threshold = int(255 * (1 - _SENSITIVITY / 100))
    diff      = np.abs(np.diff(arr.astype(np.int16), axis=1))
    valid     = (diff.max(axis=1) <= threshold) & (
        (arr.max(axis=1).astype(np.int16) - arr.min(axis=1).astype(np.int16)) <= threshold
    )

    H   = len(valid)
    cum = np.concatenate([[0], np.cumsum(valid.astype(np.int32))])
    confirmed = np.zeros(H, dtype=bool)
    confirmed[: H - _WINDOW + 1] = (cum[_WINDOW:] - cum[: H - _WINDOW + 1]) == _WINDOW
    return confirmed


def _nearest_confirmed(
    confirmed: np.ndarray, lo: int, hi: int, target: int,
) -> int | None:
    lo, hi = max(lo, 0), min(hi, len(confirmed))
    if lo >= hi:
        return None
    indices = np.where(confirmed[lo:hi])[0]
    if len(indices) == 0:
        return None
    abs_idx = indices + lo
    return int(abs_idx[np.argmin(np.abs(abs_idx - target))])


def _modal_width(images: list[np.ndarray]) -> int:
    widths = [img.shape[1] for img in images]
    return max(set(widths), key=widths.count)


def _resize_to_width(image: np.ndarray, w: int) -> np.ndarray:
    h, cw = image.shape[:2]
    if cw == w:
        return image
    return cv2.resize(image, (w, round(h * w / cw)), interpolation=cv2.INTER_AREA)


def _raw_boundaries(images: list[np.ndarray]) -> list[tuple[int, int]]:
    boundaries, row = [], 0
    for img in images:
        h = img.shape[0]
        boundaries.append((row, row + h))
        row += h
    return boundaries


_PREPARED_QUALITY = 92  # JPEG quality. See module docstring on the consistency-not-fidelity contract.


def _write_prepared(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rgb = image if image.ndim == 3 else cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(
        str(path), bgr,
        [cv2.IMWRITE_JPEG_QUALITY, _PREPARED_QUALITY,
         cv2.IMWRITE_JPEG_OPTIMIZE, 1],
    ):
        raise RuntimeError(f"Failed to write JPEG: {path}")
